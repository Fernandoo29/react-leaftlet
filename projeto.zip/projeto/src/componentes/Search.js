import Form from 'react-bootstrap/Form';
import FloatingLabel from 'react-bootstrap/FloatingLabel';
import InputGroup from 'react-bootstrap/InputGroup';
import { faMagnifyingGlass } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

import './Search.css';

function Search() {
  return (
    <Form>
        
      <Form.Group className="mb-3 input" controlId="exampleForm.ControlInput1">
      
        <InputGroup hasValidation>
            <FloatingLabel label="Busca">
                <Form.Control type="text" placeholder="Nome geográfico, termo, etc" />
            </FloatingLabel>
            <InputGroup.Text id="inputGroupPrepend"><FontAwesomeIcon icon={faMagnifyingGlass} /></InputGroup.Text>
            
        </InputGroup>
        <Form.Text id="passwordHelpBlock" muted>
            Nome geográfico, termo, etc
        </Form.Text>

        </Form.Group>
        
    </Form>
  );
}

export default Search;