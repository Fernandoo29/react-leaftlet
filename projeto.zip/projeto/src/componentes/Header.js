// src/Title.js

import React from 'react'
import Search from './Search';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import logo from '../imgs/BNGB-logo.svg';
import './Header.css';

function Header() {
  return (
    <div className="App-header">
        <Container fluid>
        <Row>
        <Col md={8}>
            <div className="header"><img src={logo} className="App-logo" alt="Banco de Nomes Geográficos do Brasil" /></div>
        </Col>
        <Col md={4}><div className="header"><Search /></div></Col>
        </Row>
    </Container>
    </div>
  )
}

export default Header