import React, { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, GeoJSON} from 'react-leaflet';
import { L, Icon, popup } from 'leaflet';
import './Map.css';
import 'leaflet/dist/leaflet.css';

//import data from '../data/bngb2.json';

function MapView(){
    const [geojsonData, setGeojsonData] = useState(null);
    const position = [-15.8, -55.88];
    const markers = [
        {
            geocode:[-15.8, -55.88],
            popup: "helo, I am popup 1",
            id:1
        },
        {
            geocode:[-15.9, -55.9],
            popup: "helo, I am popup 2",
            id:2
        },
        {
            geocode:[-15.4, -54.88],
            popup: "helo, I am popup 3",
            id:3
        }
    ]
    console.log(markers)
    const customIcon = new Icon(
        {
            //iconURL: require('leaflet/dist/images/marker-icon.png'),
            iconURL: require('../imgs/icone_hidrografia.svg'),
            iconSize:[30,30]
        }
    )

     /* useEffect(() => {
        fetch("http://localhost:3000/data/bngb.json")
          .then(response => response.json())
          .then(data => setGeojsonData(data));
      }, []);

      const geojsonStyle = {
      pointToLayer: (feature, latlng) => {
            if (geojsonData !== null) {
                //console.log(feature.latitude,feature.longitude, customIcon)
                return L.marker([feature.latitude,feature.longitude], {marker: customIcon})
            }
        },
        onEachFeature: (feature, layer) => {
            let popupContent = `<h6>Nome: ${feature.properties.name}</h6>`
            popupContent += `<a href="">link</a>`
            layer.bindPopup(popupContent)
        }
      };
    
      if (!geojsonData) {
        return <div>Loading...</div>;
      }
  
      console.log(geojsonData)*/

    return(

        <MapContainer center={position} zoom={5}>
            <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution="&copy; <a href='https://www.openstreetmap.org/'>OpenStreetMap</a>"
                >
                {markers.map(marker => (
 
                    <Marker position={marker.geocode}
                    key={marker.id}
                    ></Marker>
                ))}
                
            </TileLayer>

        </MapContainer>

    )

}

    
export default MapView;