// src/Title.js

import React from 'react'
import './Menu.css';
//import { makeStyles } from '@material-ui/core/styles';
import Accordion from 'react-bootstrap/Accordion';

// const useStyles = makeStyles((theme) => ({
//   root: {
//     width: '100%',
//     background: 'green',
//     height: '90vh'
//   },
//   heading: {
//     fontSize: theme.typography.pxToRem(15),
//     fontWeight: theme.typography.fontWeightRegular,
//   },
// }));

function Menu() {
  //const classes = useStyles();
  return (
    <div className="Menu">
      <form>
      <Accordion>
      <Accordion.Item eventKey="0">
        <Accordion.Header><input type="checkbox" className="Checkbox" name="hidrografia" id="hidrografia"/><label htmlFor="hidrografia">Hidrografia</label></Accordion.Header>
        <Accordion.Body>
        <ul>
            <li><input type="checkbox" className="Checkbox" name="hidrografia_1" id="hidrografia_1"/><label htmlFor="hidrografia_1">Canal ou Vala</label></li>
            <li><input type="checkbox" className="Checkbox" name="hidrografia_2" id="hidrografia_2"/><label htmlFor="hidrografia_2">Corredeira</label></li>
          </ul>
        </Accordion.Body>
      </Accordion.Item>
      <Accordion.Item eventKey="1">
      <Accordion.Header><input type="checkbox" className="Checkbox" name="relevo" id="relevo"/><label htmlFor="relevo">Relevo</label></Accordion.Header>
        <Accordion.Body>
          <ul>
            <li><input type="checkbox" className="Checkbox" name="relevo_1" id="relevo_1"/><label htmlFor="relevo_1">Arquipélago</label></li>
            <li><input type="checkbox" className="Checkbox" name="relevo_2" id="relevo_2"/><label htmlFor="relevo_1">Elemento Físico Natural</label></li>
          </ul>
        </Accordion.Body>
      </Accordion.Item>
    </Accordion>
      </form>
     
    </div>
  )
}

export default Menu