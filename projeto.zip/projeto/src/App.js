import './App.css';
import ThemeProvider from 'react-bootstrap/ThemeProvider'
import Header from './componentes/Header';
import Menu from './componentes/Menu';
import Map from './componentes/Map';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';



import 'bootstrap/dist/css/bootstrap.min.css';

function App() {

  return (

    <ThemeProvider breakpoints={['xxxl', 'xxl', 'xl', 'lg', 'md', 'sm', 'xs', 'xxs']} minBreakpoint="xxs">
  
      <div className="App">
       <Header />

       <Container fluid>
        <Row>
          <Col md={3}>
            <Menu />
          </Col>
          <Col md={9}>
              <Map/>
          </Col>
        </Row>
      </Container>
      </div>

    </ThemeProvider>
  );
}

export default App;
